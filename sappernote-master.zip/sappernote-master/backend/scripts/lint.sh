#!/usr/bin/env bash

pdm lint
