#!/usr/bin/env bash

ruff format --check
