#!/usr/bin/env bash

pdm export -p . -o requirements.txt --without-hashes
