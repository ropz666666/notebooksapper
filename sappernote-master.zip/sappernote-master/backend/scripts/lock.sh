#!/usr/bin/env bash

pdm lock --python=">=3.10" --append
