Generic single-database configuration with an async dbapi.

If you add a new app to the framework, be sure to read the contents of the `env.py` file.
