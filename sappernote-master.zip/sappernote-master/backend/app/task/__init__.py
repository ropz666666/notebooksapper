#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

from pathlib import Path

# 导入项目根目录
sys.path.append(str(Path(__file__).resolve().parent.parent.parent.parent))
