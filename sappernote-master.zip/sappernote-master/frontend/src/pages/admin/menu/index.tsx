function AdminMenuPage() {
    return(
        <div>hello menu</div>
    )
}

export default AdminMenuPage;