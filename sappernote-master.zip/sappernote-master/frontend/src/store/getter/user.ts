import { State } from "@/types";

export const getStateUser = (state: State) => state.user