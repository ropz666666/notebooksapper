import { State } from "@/types";

export const getStateThemeToken = (state: State) => state.theme.token
