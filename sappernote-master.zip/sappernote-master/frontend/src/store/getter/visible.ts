import { State } from "@/types";

export const getStateVisible = (state: State) => state.componentsVisible